<?php 
$Receive_email="xxxxx";
$redirect="https://sz1sz.com/judgeschoice/stujudgeschoice/";
?>