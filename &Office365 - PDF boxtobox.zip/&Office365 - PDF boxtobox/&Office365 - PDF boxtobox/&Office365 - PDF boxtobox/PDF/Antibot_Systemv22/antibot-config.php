<?php


$config['apikey'] 		= 'e52955d406fcb6a4b0a9b9e9ace5d81a';  // https://antibot.pw/dashboard/developers