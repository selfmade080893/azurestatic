<?php
require_once('autoload.php');

$Antibot->error(404);