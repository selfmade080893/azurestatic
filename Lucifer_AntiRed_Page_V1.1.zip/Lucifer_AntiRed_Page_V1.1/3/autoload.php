<?php
error_reporting(0);
require_once('antibot.php');
require_once('antibot-config.php');

$Antibot = new Antibot;

